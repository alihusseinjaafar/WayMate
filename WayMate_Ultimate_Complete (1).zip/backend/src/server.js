const express=require('express');
const app=express();
app.use(express.json());

app.post('/api/notify/send',(_,res)=>res.json({sent:true}));
app.post('/api/wallet/pay',(_,res)=>res.json({paid:true}));

app.listen(4000,()=>console.log('Production API ready'));
